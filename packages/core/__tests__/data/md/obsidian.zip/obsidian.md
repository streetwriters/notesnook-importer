#ppm #servicenow 
- Project Workspace
	- Planning Console
		![[Pasted image 20230625105750.jpg]]
	- Project Workbench
		![[Pasted image 20230625105750.jpg]]
	- Resource Allocation Workbench
	- Financial Summary
		![[Pasted image 20230625105750.jpg]]
	- Status Report
		![[Pasted image 20230625105750.jpg]]
- New Project Workspace
- Demand Workbench
- Demand Roadmap
- Time Sheet Portal