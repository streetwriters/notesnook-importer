# Temp note

![image](./assets/1_percent_emprovement_vs_decline.jpg)
